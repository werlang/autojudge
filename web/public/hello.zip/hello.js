process.openStdin().on('data', data => main(data.toString().trim().split(/\s+/g)));

async function main(input) {
    const a = parseInt(input[0]);
    const b = parseInt(input[1]);
    console.log(`X = ${a + b}`);
}