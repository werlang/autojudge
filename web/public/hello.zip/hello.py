[a, b] = input().split()
[a, b] = [int(a), int(b)]
print("X = " + str(a + b) + "\n")
