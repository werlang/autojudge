<?php
$input = explode(" ", fgets(STDIN));
$a = intval($input[0]);
$b = intval($input[1]);
echo "X = " . ($a + $b) . "\n";