#include <stdio.h>

int main() {
    int a, b, x;
    scanf("%d %d", &a, &b);
    printf("X = %d\n", a + b);
    return 0;
}